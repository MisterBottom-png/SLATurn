# UI/UX Redesign Plan

## Manager-focused flow
1. **Upload**
   - Drag/drop zone with clear replace/reset actions.
   - Workbook name, size, selected sheet, and sheet count summary.
   - Auto-run after required columns are detected.
2. **Import settings**
   - Hidden by default to keep normal use simple.
   - Expands automatically when required mappings are missing.
   - Allows sheet selection, header-row override, and manual field mapping.
3. **Filters**
   - Defaults focus on the latest/current reporting month.
   - Month selector is restricted to the latest/current month and previous month.
   - Default products: Duvet, Bed set, Pillow pair, Pillow.
   - Default methods: Estonia-to-UK and customer methods.
   - "Delivery not required" remains included by default.
4. **Results**
   - KPI tiles, monthly summary table, late-order review, missing-date review, order-number list, row-level table, mismatch report, and excluded rows.
   - Charts are removed so managers can focus on the current or previous month and row-level misses.

## Mapping UX and data validation
- Normalize header labels and propose defaults using synonym lookup.
- Order number is required so exports can identify every row.
- Block calculation until all required columns are mapped.
- Exclude rows with missing or invalid order, shipped, or required dates and highlight them red in the excluded-row review.
- Show missing-date reasons clearly so upload/import problems can be fixed at source.

## Tables, filters, and miss explanation
- Monthly summary is compact by default, with an optional detail view.
- Row-level tables are paginated and horizontally scrollable for wide exports.
- Ship - required is shown as signed calendar days: positive means late, negative means early.
- Late-order and missing-date cards explain the main misses without requiring chart interpretation.
- Exports include order numbers in monthly, included-row, late-row, mismatch, and excluded-row outputs.

## Accessibility checklist
- ARIA support for tabs, dialog, and select controls via Radix primitives.
- Keyboard navigation across upload, settings, filters, and table controls.
- Visible focus states with consistent outline.
- Screen-reader labels for inputs and dropdowns.
- Color contrast verified for text over dark backgrounds.

## Visual system/tokens
- Dark UI with slate backgrounds and emerald accent for primary actions.
- Tailwind tokens set via CSS variables for easy theming.
- Rounded cards, subtle borders, and consistent spacing.
