export type FieldKey =
  | 'order_date'
  | 'shipping_date'
  | 'required_arrival_date'
  | 'status'
  | 'method'
  | 'product'
  | 'destination_country'
  | 'order_id'
  | 'customer';

export type RequiredFieldKey =
  | 'order_date'
  | 'shipping_date'
  | 'required_arrival_date'
  | 'status'
  | 'method'
  | 'product'
  | 'destination_country';

export interface WorkbookInfo {
  name: string;
  size: number;
  sheetNames: string[];
  sheetFilters: Record<string, SheetFilterInfo>;
  sourceType?: 'excel' | 'web';
  sourceUrl?: string;
  rowCount?: number;
}

export interface SheetFilterInfo {
  hasAutoFilter: boolean;
  range?: string;
}

export interface SheetPreview {
  rows: string[][];
}

export interface FieldMapping {
  [key: string]: string | null;
}

export interface HeaderCandidate {
  rowIndex: number;
  confidence: number;
}

export interface ParsedRow {
  raw: Record<string, unknown>;
  normalized: Record<string, string>;
}

export interface EnrichedRow {
  orderDate: Date | null;
  shippingDate: Date | null;
  requiredArrivalDate: Date | null;
  status: string;
  method: string;
  product: string;
  destinationCountry: string;
  orderId?: string;
  customer?: string;
  turnoverDays: number | null;
  /** Signed calendar-day difference: shipped date - required arrival date. Positive means late; negative means early. */
  shipVsRequiredDays: number | null;
  /** Date fields that are missing or unparseable and should be highlighted for review. */
  missingDateFields: string[];
  /** On-time result based on required date vs shipped date. */
  isOnTime: boolean | null;
  monthKey: string | null;
  /** Month used only for showing missing-date rows in the selected report. */
  correctionMonthKey: string | null;
}

export interface ExclusionReason {
  reason: string;
  count: number;
}

export interface QualityMetrics {
  rawRows: number;
  validRows: number;
  includedRows: number;
  exclusions: ExclusionReason[];
}

export interface MonthlySummary {
  month: string;
  shipped: number;
  onTime: number;
  late: number;
  onTimeRate: number;
  averageTurnover: number | null;
  /** Average shipped date - required date difference for rows in this month. */
  averageShipVsRequiredDays: number | null;
  /** All order numbers included in this month, used by manager exports. */
  orderNumbers: string[];
  /** Highest positive shipped date - required date difference. 0 means no late shipments. */
  maxLateDays: number | null;
  /** Order numbers that shipped after the required date. */
  lateOrderNumbers: string[];
}

export interface CalculationResult {
  monthly: MonthlySummary[];
  rows: EnrichedRow[];
  quality: QualityMetrics;
  excludedRows: Array<{ row: EnrichedRow; reason: string }>;
}

export interface RulesConfig {
  excludeChina: boolean;
  statusMatchers: string[];
  statusRegex: string;
}

export interface FiltersConfig {
  methods: string[];
  products: string[];
  monthRange: [string | null, string | null];
  deliveryNotRequired: boolean;
}

export interface Preset {
  id: string;
  name: string;
  createdAt: string;
  mapping: FieldMapping;
  rules: RulesConfig;
  filters: FiltersConfig;
}
