import { calculateMetrics } from '@/calculations/metrics';
import type { FieldMapping, FiltersConfig, RulesConfig } from '@/types';

describe('calculateMetrics', () => {
  const mapping: FieldMapping = {
    order_date: 'Order Date',
    shipping_date: 'Ship Date',
    required_arrival_date: 'Required Date',
    status: 'Status',
    method: 'Method',
    product: 'Product',
    destination_country: 'Country',
    order_id: 'Order Number',
    customer: null
  };

  const rules: RulesConfig = {
    excludeChina: true,
    statusMatchers: ['shipped'],
    statusRegex: ''
  };

  const filters: FiltersConfig = {
    methods: [],
    products: [],
    monthRange: [null, null],
    deliveryNotRequired: true
  };

  it('computes on-time and late counts by month', () => {
    const rows = [
      {
        'Order Number': 'ORD-1',
        'Order Date': 45382,
        'Ship Date': 45384,
        'Required Date': 45385,
        Status: 'Shipped',
        Method: 'Air',
        Product: 'A',
        Country: 'Finland'
      },
      {
        'Order Number': 'ORD-2',
        'Order Date': 45382,
        'Ship Date': 45390,
        'Required Date': 45385,
        Status: 'Shipped',
        Method: 'Air',
        Product: 'A',
        Country: 'Finland'
      }
    ];

    const result = calculateMetrics(rows, mapping, rules, filters);
    expect(result.monthly).toHaveLength(1);
    expect(result.monthly[0].shipped).toBe(2);
    expect(result.monthly[0].onTime).toBe(1);
    expect(result.monthly[0].late).toBe(1);
    expect(result.monthly[0].orderNumbers).toEqual(['ORD-1', 'ORD-2']);
  });

  it('calculates shipped date minus required date as signed days', () => {
    const rows = [
      {
        'Order Number': 'EARLY-1',
        'Order Date': '2024-01-01',
        'Required Date': '2024-01-10',
        'Ship Date': '2024-01-08',
        Status: 'Shipped',
        Method: 'Air',
        Product: 'A',
        Country: 'Finland'
      },
      {
        'Order Number': 'LATE-1',
        'Order Date': '2024-01-01',
        'Required Date': '2024-01-10',
        'Ship Date': '2024-01-13',
        Status: 'Shipped',
        Method: 'Air',
        Product: 'A',
        Country: 'Finland'
      }
    ];

    const result = calculateMetrics(rows, mapping, rules, filters);
    expect(result.rows.map((row) => row.shipVsRequiredDays)).toEqual([-2, 3]);
    expect(result.monthly[0].averageShipVsRequiredDays).toBe(0.5);
    expect(result.monthly[0].maxLateDays).toBe(3);
    expect(result.monthly[0].lateOrderNumbers).toEqual(['LATE-1']);
  });

  it('tracks exclusions for status mismatch and country', () => {
    const rows = [
      {
        'Order Number': 'ORD-3',
        'Order Date': 45382,
        'Ship Date': 45384,
        'Required Date': 45385,
        Status: 'Pending',
        Method: 'Air',
        Product: 'A',
        Country: 'Finland'
      },
      {
        'Order Number': 'ORD-4',
        'Order Date': 45382,
        'Ship Date': 45384,
        'Required Date': 45385,
        Status: 'Shipped',
        Method: 'Air',
        Product: 'A',
        Country: 'China'
      }
    ];

    const result = calculateMetrics(rows, mapping, rules, filters);
    const reasons = result.quality.exclusions.map((item) => item.reason);
    expect(reasons).toContain('Status mismatch');
    expect(reasons).toContain('Excluded country');
    expect(result.rows).toHaveLength(0);
  });

  it('excludes and labels rows with missing required dates', () => {
    const rows = [
      {
        'Order Number': 'ORD-5',
        'Order Date': '2024-01-01',
        'Ship Date': '2024-01-08',
        'Required Date': '',
        Status: 'Shipped',
        Method: 'Air',
        Product: 'A',
        Country: 'Finland'
      }
    ];

    const result = calculateMetrics(rows, mapping, rules, filters);
    expect(result.rows).toHaveLength(0);
    expect(result.excludedRows[0].reason).toBe('Missing or invalid date: Required date');
    expect(result.excludedRows[0].row.missingDateFields).toEqual(['Required date']);
  });

  it('does not exclude valid rows when order number is unavailable', () => {
    const rows = [
      {
        'Order Date': '2024-01-01',
        'Ship Date': '2024-01-08',
        'Required Date': '2024-01-10',
        Status: 'Shipped',
        Method: 'Air',
        Product: 'A',
        Country: 'Finland'
      }
    ];

    const result = calculateMetrics(rows, { ...mapping, order_id: null }, rules, filters);
    expect(result.rows).toHaveLength(1);
    expect(result.monthly[0].orderNumbers).toEqual([]);
  });

});
