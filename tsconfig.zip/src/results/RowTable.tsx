import { useMemo, useState } from 'react';
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  getPaginationRowModel,
  useReactTable
} from '@tanstack/react-table';
import type { EnrichedRow } from '@/types';

interface RowTableProps {
  data: EnrichedRow[];
}

export default function RowTable({ data }: RowTableProps) {
  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 10 });

  const columns = useMemo<ColumnDef<EnrichedRow>[]>(
    () => [
      {
        accessorKey: 'orderId',
        header: 'Order number',
        cell: (info) => info.getValue<string | undefined>()?.trim() || '-'
      },
      { accessorKey: 'orderDate', header: 'Order date', cell: (info) => formatDate(info.getValue()) },
      { accessorKey: 'requiredArrivalDate', header: 'Required date', cell: (info) => formatDate(info.getValue()) },
      { accessorKey: 'shippingDate', header: 'Shipped date', cell: (info) => formatDate(info.getValue()) },
      {
        accessorKey: 'shipVsRequiredDays',
        header: 'Days early/late',
        cell: (info) => formatSignedDays(info.getValue<number | null>())
      },
      { accessorKey: 'status', header: 'Status' },
      { accessorKey: 'method', header: 'Method' },
      { accessorKey: 'product', header: 'Product' },
      { accessorKey: 'destinationCountry', header: 'Country' },
      {
        accessorKey: 'turnoverDays',
        header: 'Turnaround (days)',
        cell: (info) => info.getValue<number | null>() ?? '-'
      },
      {
        accessorKey: 'isOnTime',
        header: 'On-time',
        cell: (info) => formatBool(info.getValue())
      }
    ],
    []
  );

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    state: { pagination },
    onPaginationChange: setPagination
  });

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>Rows: {data.length}</span>
        <label className="flex items-center gap-2">
          Page size
          <select
            className="rounded-md border border-border bg-background px-2 py-1"
            value={pagination.pageSize}
            onChange={(event) => setPagination({ pageIndex: 0, pageSize: Number(event.target.value) })}
          >
            {[10, 25, 50, 100].map((size) => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>
        </label>
      </div>
      <div className="overflow-auto rounded-lg border border-border">
        <table className="min-w-[1040px] w-full text-left text-xs">
          <thead className="bg-card text-muted-foreground">
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <th key={header.id} className="px-3 py-2">
                    {flexRender(header.column.columnDef.header, header.getContext())}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.map((row) => (
              <tr key={row.id} className="border-t border-border">
                {row.getVisibleCells().map((cell) => (
                  <td key={cell.id} className="px-3 py-2">
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <button
          className="underline disabled:opacity-50"
          onClick={() => table.previousPage()}
          disabled={!table.getCanPreviousPage()}
        >
          Previous
        </button>
        <span>
          Page {table.getState().pagination.pageIndex + 1} of {table.getPageCount()}
        </span>
        <button
          className="underline disabled:opacity-50"
          onClick={() => table.nextPage()}
          disabled={!table.getCanNextPage()}
        >
          Next
        </button>
      </div>
    </div>
  );
}

function formatDate(value: unknown) {
  if (!value || !(value instanceof Date)) return '-';
  return value.toISOString().slice(0, 10);
}

function formatBool(value: unknown) {
  if (value === null || value === undefined) return '-';
  if (typeof value !== 'boolean') return '-';
  return value ? 'Yes' : 'No';
}

function formatSignedDays(value: number | null | undefined) {
  if (value === null || value === undefined) return '-';
  const abs = Math.abs(value);
  const unit = abs === 1 ? 'day' : 'days';
  if (value > 0) return `+${value} ${unit} late`;
  if (value < 0) return `${value} ${unit} early`;
  return '0 days on time';
}
