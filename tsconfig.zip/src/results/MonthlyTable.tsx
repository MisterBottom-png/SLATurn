import { useMemo } from 'react';
import { ColumnDef, flexRender, getCoreRowModel, useReactTable } from '@tanstack/react-table';
import type { MonthlySummary } from '@/types';

interface MonthlyTableProps {
  data: MonthlySummary[];
}

export default function MonthlyTable({ data }: MonthlyTableProps) {
  const columns = useMemo<ColumnDef<MonthlySummary>[]>(
    () => [
      { accessorKey: 'month', header: 'Month' },
      { accessorKey: 'shipped', header: 'Orders included' },
      { accessorKey: 'onTime', header: 'On-time orders' },
      { accessorKey: 'late', header: 'Late orders' },
      {
        accessorKey: 'onTimeRate',
        header: 'On-time %',
        cell: (info) => `${Math.round((info.getValue<number>() ?? 0) * 100)}%`
      },
      {
        accessorKey: 'averageShipVsRequiredDays',
        header: 'Avg days early/late',
        cell: (info) => formatAverageSignedDays(info.getValue<number | null>())
      },
      {
        accessorKey: 'maxLateDays',
        header: 'Max late',
        cell: (info) => formatMaxLate(info.getValue<number | null>())
      },
      {
        accessorKey: 'lateOrderNumbers',
        header: 'Late order numbers',
        cell: (info) => formatOrderNumbers(info.getValue<string[]>())
      },
      {
        accessorKey: 'orderNumbers',
        header: 'All order numbers',
        cell: (info) => formatOrderNumbers(info.getValue<string[]>())
      }
    ],
    []
  );

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel()
  });

  return (
    <div className="space-y-2" data-pdf-avoid-break="true">
      <div>
        <p className="text-sm font-semibold">Monthly summary</p>
        <p className="text-xs text-muted-foreground">
          Required vs shipped uses shipped date minus required date. Positive values are late.
        </p>
      </div>

      <div className="overflow-auto rounded-lg border border-border">
        <table className="min-w-[980px] w-full text-left text-xs">
          <thead className="bg-card text-muted-foreground">
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <th key={header.id} className="px-3 py-2">
                    {flexRender(header.column.columnDef.header, header.getContext())}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.map((row) => (
              <tr key={row.id} className="border-t border-border">
                {row.getVisibleCells().map((cell) => (
                  <td key={cell.id} className="px-3 py-2">
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function formatAverageSignedDays(value: number | null | undefined) {
  if (value === null || value === undefined) return '-';
  const display = value > 0 ? `+${value.toFixed(1)}` : value.toFixed(1);
  if (value > 0) return `${display} days late`;
  if (value < 0) return `${display} days early`;
  return '0.0 days on time';
}

function formatMaxLate(value: number | null | undefined) {
  if (value === null || value === undefined) return '-';
  return value > 0 ? `+${value} ${value === 1 ? 'day' : 'days'} late` : '0 days on time';
}

function formatOrderNumbers(values: string[] | undefined) {
  if (!values?.length) return '-';
  return values.join(', ');
}
