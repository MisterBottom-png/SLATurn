import { useMemo, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { buildDefaultFilters, DEFAULT_FILTERS, DEFAULT_PRODUCT_FILTERS } from '@/common/constants';
import type { FiltersConfig } from '@/types';

interface FiltersPanelProps {
  filters: FiltersConfig;
  onChangeFilters: (filters: FiltersConfig) => void;
  availableMethods: string[];
  availableProducts: string[];
  availableMonths: string[];
}

function sameList(left: string[], right: string[]) {
  if (left.length !== right.length) return false;
  const sortedLeft = [...left].sort();
  const sortedRight = [...right].sort();
  return sortedLeft.every((value, index) => value === sortedRight[index]);
}

export default function FiltersPanel({
  filters,
  onChangeFilters,
  availableMethods,
  availableProducts,
  availableMonths
}: FiltersPanelProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [newMethod, setNewMethod] = useState('');
  const [newProduct, setNewProduct] = useState('');

  const reportingMonths = useMemo(() => availableMonths, [availableMonths]);
  const defaultFilters = useMemo(
    () => buildDefaultFilters(availableMethods, availableProducts, availableMonths),
    [availableMethods, availableProducts, availableMonths]
  );
  const selectedMonth = filters.monthRange[1] ?? filters.monthRange[0] ?? '';

  const addFilter = (type: 'methods' | 'products', value: string) => {
    if (!value || value === '__none__') return false;
    const list = filters[type];
    if (list.includes(value)) return false;
    onChangeFilters({ ...filters, [type]: [...list, value] });
    return true;
  };

  const removeFilter = (type: 'methods' | 'products', value: string) => {
    onChangeFilters({ ...filters, [type]: filters[type].filter((item) => item !== value) });
  };

  const resetDefaults = () => {
    onChangeFilters(defaultFilters);
  };

  const clearFilters = () => {
    onChangeFilters({
      ...filters,
      methods: [],
      products: [],
      monthRange: [null, null],
      deliveryNotRequired: DEFAULT_FILTERS.deliveryNotRequired
    });
  };

  const hasDefaultFilters = useMemo(() => {
    return (
      sameList(filters.methods, defaultFilters.methods) &&
      sameList(filters.products, defaultFilters.products) &&
      filters.deliveryNotRequired === defaultFilters.deliveryNotRequired
    );
  }, [filters, defaultFilters]);

  const isMethodAddDisabled = !newMethod || newMethod === '__none__' || filters.methods.includes(newMethod);
  const isProductAddDisabled = !newProduct || newProduct === '__none__' || filters.products.includes(newProduct);
  const monthLabel = selectedMonth || 'All months';
  const methodSummary = filters.methods.length ? `${filters.methods.length} method${filters.methods.length === 1 ? '' : 's'}` : 'All methods';
  const productSummary = filters.products.length ? `${filters.products.length} product${filters.products.length === 1 ? '' : 's'}` : 'All products';

  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <p className="text-sm font-semibold">Filters</p>
          <p className="text-xs text-muted-foreground">
            Defaults focus managers on the current calendar month, the selected product group, and Estonia-to-UK/customer methods.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button type="button" variant={isEditing ? 'secondary' : 'default'} size="sm" onClick={() => setIsEditing((value) => !value)}>
            {isEditing ? 'Done' : 'Edit filters'}
          </Button>
          <Button type="button" variant="secondary" size="sm" onClick={resetDefaults}>
            Reset defaults
          </Button>
          {isEditing ? (
            <Button type="button" variant="outline" size="sm" onClick={clearFilters}>
              Clear filters
            </Button>
          ) : null}
        </div>
      </div>

      {!isEditing ? (
        <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          <div className="rounded-md border border-border bg-background/60 p-3">
            <p className="text-xs text-muted-foreground">Month</p>
            <p className="mt-1 text-sm font-semibold">{monthLabel}</p>
            <p className="mt-1 text-xs text-muted-foreground">Basis: required date vs shipped date</p>
          </div>
          <div className="rounded-md border border-border bg-background/60 p-3">
            <p className="text-xs text-muted-foreground">Methods</p>
            <p className="mt-1 text-sm font-semibold">{methodSummary}</p>
            <p className="mt-1 truncate text-xs text-muted-foreground">
              {filters.methods.length ? filters.methods.slice(0, 2).join(', ') : 'No method filter'}
            </p>
          </div>
          <div className="rounded-md border border-border bg-background/60 p-3">
            <p className="text-xs text-muted-foreground">Products</p>
            <p className="mt-1 text-sm font-semibold">{productSummary}</p>
            <p className="mt-1 truncate text-xs text-muted-foreground">
              {filters.products.length ? filters.products.slice(0, 2).join(', ') : 'No product filter'}
            </p>
          </div>
          <div className="rounded-md border border-border bg-background/60 p-3">
            <p className="text-xs text-muted-foreground">Delivery not required</p>
            <p className="mt-1 text-sm font-semibold">{filters.deliveryNotRequired ? 'Included' : 'Excluded'}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              {hasDefaultFilters ? 'Default scope' : 'Custom scope'}
            </p>
          </div>
        </div>
      ) : (
        <>
          <div className="mt-3 rounded-md border border-border bg-background/60 p-3 text-xs text-muted-foreground">
            <span className="font-semibold text-foreground">Default products:</span> {DEFAULT_PRODUCT_FILTERS.join(', ')}.{' '}
            <span className="font-semibold text-foreground">Default methods:</span> Estonia-to-UK and customer methods.{' '}
            <span className="font-semibold text-foreground">Delivery not required:</span> included.
          </div>

          <div className="mt-4 grid gap-4 md:grid-cols-2">
        <div className="space-y-2 md:col-span-2">
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              className="h-4 w-4 accent-[hsl(var(--primary))]"
              checked={filters.deliveryNotRequired}
              onChange={(event) => onChangeFilters({ ...filters, deliveryNotRequired: event.target.checked })}
            />
            Include "Delivery not required"
          </label>
          <p className="text-xs text-muted-foreground">
            This stays ticked by default. Untick it only when those rows should be removed.
          </p>
        </div>

        <div className="space-y-2">
          <label className="text-xs text-muted-foreground">Shipping methods</label>
          <Select value={newMethod} onValueChange={(value) => setNewMethod(value)}>
            <SelectTrigger aria-label="Filter by method">
              <SelectValue className="truncate" placeholder="Select method" />
            </SelectTrigger>
            <SelectContent>
              {availableMethods.length ? (
                availableMethods.map((method) => (
                  <SelectItem key={method} value={method}>
                    {method}
                  </SelectItem>
                ))
              ) : (
                <SelectItem value="__none__" disabled>
                  No methods detected
                </SelectItem>
              )}
            </SelectContent>
          </Select>
          <Button
            type="button"
            variant="secondary"
            size="sm"
            disabled={isMethodAddDisabled}
            onClick={() => {
              if (addFilter('methods', newMethod)) {
                setNewMethod('');
              }
            }}
          >
            Add method
          </Button>
          <div className="flex flex-wrap gap-2">
            {filters.methods.length ? (
              filters.methods.map((method) => (
                <Badge
                  key={method}
                  className="max-w-full cursor-pointer truncate hover:bg-muted/70"
                  onClick={() => removeFilter('methods', method)}
                >
                  {method} ×
                </Badge>
              ))
            ) : (
              <span className="text-xs text-muted-foreground">All methods</span>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs text-muted-foreground">Products</label>
          <Select value={newProduct} onValueChange={(value) => setNewProduct(value)}>
            <SelectTrigger aria-label="Filter by product">
              <SelectValue className="truncate" placeholder="Select product" />
            </SelectTrigger>
            <SelectContent>
              {availableProducts.length ? (
                availableProducts.map((product) => (
                  <SelectItem key={product} value={product}>
                    {product}
                  </SelectItem>
                ))
              ) : (
                <SelectItem value="__none__" disabled>
                  No products detected
                </SelectItem>
              )}
            </SelectContent>
          </Select>
          <Button
            type="button"
            variant="secondary"
            size="sm"
            disabled={isProductAddDisabled}
            onClick={() => {
              if (addFilter('products', newProduct)) {
                setNewProduct('');
              }
            }}
          >
            Add product
          </Button>
          <div className="flex flex-wrap gap-2">
            {filters.products.length ? (
              filters.products.map((product) => (
                <Badge
                  key={product}
                  className="max-w-full cursor-pointer truncate hover:bg-muted/70"
                  onClick={() => removeFilter('products', product)}
                >
                  {product} ×
                </Badge>
              ))
            ) : (
              <span className="text-xs text-muted-foreground">All products</span>
            )}
          </div>
        </div>
      </div>

          <div className="mt-4 grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <label className="text-xs text-muted-foreground">Reporting month</label>
          <Select
            value={selectedMonth}
            onValueChange={(value) =>
              onChangeFilters({
                ...filters,
                monthRange: value === '__none__' ? [null, null] : [value, value]
              })
            }
          >
            <SelectTrigger aria-label="Reporting month">
              <SelectValue className="truncate" placeholder="Current month" />
            </SelectTrigger>
            <SelectContent>
              {reportingMonths.length ? (
                reportingMonths.map((month, index) => {
                  const isCurrent = index === reportingMonths.length - 1;
                  const label = isCurrent ? `${month} — Current month` : `${month} — Previous month`;
                  return (
                    <SelectItem key={month} value={month}>
                      {label}
                    </SelectItem>
                  );
                })
              ) : (
                <SelectItem value="__none__" disabled>
                  No months detected
                </SelectItem>
              )}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">Only the current calendar month and previous calendar month are available.</p>
        </div>
      </div>

      <p className="mt-3 text-xs text-muted-foreground">
        {hasDefaultFilters ? 'Default filters applied.' : 'Custom filters applied.'}
      </p>
        </>
      )}
    </div>
  );
}
