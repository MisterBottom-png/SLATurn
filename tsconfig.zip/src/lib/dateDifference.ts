export function formatShipVsRequired(days: number | null | undefined): string {
  if (days === null || days === undefined) return '—';
  if (days === 0) return '0 days on time';
  const abs = Math.abs(days);
  const unit = abs === 1 ? 'day' : 'days';
  return days > 0 ? `+${abs} ${unit} late` : `-${abs} ${unit} early`;
}

export function formatSignedDayNumber(days: number | null | undefined): string {
  if (days === null || days === undefined) return '';
  return days > 0 ? `+${days}` : String(days);
}
