import { useCallback, useEffect, useMemo, useRef, useState, type RefObject } from 'react';
import * as XLSX from 'xlsx';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import FiltersPanel from '@/components/FiltersPanel';
import StepHeader from '@/steps/StepHeader';
import StepMapping from '@/steps/StepMapping';
import StepResults from '@/steps/StepResults';
import StepRules from '@/steps/StepRules';
import StepReview from '@/steps/StepReview';
import StepSheet from '@/steps/StepSheet';
import StepUpload from '@/steps/StepUpload';
import { calculateMetrics } from '@/calculations/metrics';
import {
  buildDefaultFilters,
  DEFAULT_RULES,
  getCurrentPreviousMonths,
  OPTIONAL_FIELDS,
  REQUIRED_FIELDS
} from '@/common/constants';
import { getSheetRows, getWorkbookFilterInfo, readWorkbook } from '@/excel/workbook';
import { detectHeaderRow } from '@/parsing/headerDetection';
import { mapRowsToObjects, normalizeCellValue } from '@/parsing/rows';
import { suggestMapping } from '@/parsing/normalize';
import {
  addPreset,
  deletePreset,
  getPreset,
  loadFilters,
  loadMapping,
  loadPresets,
  loadRules,
  saveFilters,
  saveMapping,
  saveRules
} from '@/lib/storage';
import type { CalculationResult, FieldMapping, FiltersConfig, Preset, RulesConfig, WorkbookInfo } from '@/types';
import { DEFAULT_WEB_FEED_URL, readWebFeed } from '@/web/feed';

const emptyMapping: FieldMapping = {
  order_date: null,
  shipping_date: null,
  required_arrival_date: null,
  status: null,
  method: null,
  product: null,
  destination_country: null,
  order_id: null,
  customer: null
};

function makeSignature(payload: unknown) {
  try {
    return JSON.stringify(payload);
  } catch {
    return String(Date.now());
  }
}

export default function App() {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [workbook, setWorkbook] = useState<XLSX.WorkBook | null>(null);
  const [workbookInfo, setWorkbookInfo] = useState<WorkbookInfo | null>(null);
  const [selectedSheet, setSelectedSheet] = useState<string | null>(null);
  const [sheetRows, setSheetRows] = useState<unknown[][]>([]);
  const [headerRowIndex, setHeaderRowIndex] = useState(0);
  const [mapping, setMapping] = useState<FieldMapping>(emptyMapping);
  const [rules, setRules] = useState<RulesConfig>(DEFAULT_RULES);
  const [filters, setFilters] = useState<FiltersConfig>(() => buildDefaultFilters());
  const [calculation, setCalculation] = useState<CalculationResult | null>(null);
  const [presets, setPresets] = useState<Preset[]>([]);
  const [lastRunSignature, setLastRunSignature] = useState<string | null>(null);
  const [hasSavedFilters, setHasSavedFilters] = useState<boolean | null>(null);
  const [webUrl, setWebUrl] = useState(DEFAULT_WEB_FEED_URL);
  const [webError, setWebError] = useState<string | null>(null);
  const [isLoadingWeb, setIsLoadingWeb] = useState(false);
  const [webLoadStatus, setWebLoadStatus] = useState<'idle' | 'loading' | 'ready' | 'failed'>('idle');
  const [showExcelFallback, setShowExcelFallback] = useState(false);
  const [lastRefreshedAt, setLastRefreshedAt] = useState<string | null>(null);
  const autoAppliedFilters = useRef(false);
  const didAutoLoadWeb = useRef(false);
  const importRef = useRef<HTMLDivElement | null>(null);
  const rulesRef = useRef<HTMLDivElement | null>(null);
  const reviewRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const storedMapping = loadMapping();
    if (storedMapping) setMapping({ ...emptyMapping, ...storedMapping });
    const storedRules = loadRules();
    if (storedRules) setRules(storedRules);
    const storedFilters = loadFilters();
    if (storedFilters) {
      setFilters(storedFilters);
      setHasSavedFilters(true);
    } else {
      setHasSavedFilters(false);
    }
    setPresets(loadPresets());
  }, []);

  useEffect(() => {
    saveMapping(mapping);
  }, [mapping]);

  useEffect(() => {
    saveRules(rules);
  }, [rules]);

  useEffect(() => {
    saveFilters(filters);
  }, [filters]);

  useEffect(() => {
    if (!workbook || !selectedSheet) return;
    const rows = getSheetRows(workbook, selectedSheet);
    setSheetRows(rows);
    const detected = detectHeaderRow(rows);
    setHeaderRowIndex(detected.rowIndex);
  }, [workbook, selectedSheet]);

  const parsed = useMemo(() => {
    if (!sheetRows.length) return null;
    return mapRowsToObjects(sheetRows, headerRowIndex);
  }, [sheetRows, headerRowIndex]);

  useEffect(() => {
    if (!parsed?.headers?.length) return;
    const suggestions = suggestMapping(parsed.headers);
    setMapping((prev) => {
      const next = { ...prev };
      Object.entries(suggestions).forEach(([key, value]) => {
        const current = (next as any)[key] as string | null | undefined;
        const isRequired = REQUIRED_FIELDS.some((field) => field.key === key);

        if (isRequired) {
          // Fully automated mapping for required fields.
          if (value && value !== current) {
            (next as any)[key] = value;
          }
          return;
        }

        if (!current || !parsed.headers.includes(current)) {
          (next as any)[key] = value;
        }
      });
      return next;
    });
  }, [parsed?.headers]);

  const missingRequired = useMemo(() => {
    const headers = parsed?.headers ?? [];
    return REQUIRED_FIELDS.filter((field) => {
      const col = mapping[field.key];
      return !(col && headers.includes(col));
    });
  }, [mapping, parsed]);

  const requiredMapped = missingRequired.length === 0;

  useEffect(() => {
    if (workbookInfo && missingRequired.length) {
      setShowAdvanced(true);
    }
  }, [workbookInfo, missingRequired.length]);

  const availableMethods = useMemo(() => {
    if (!parsed || !mapping.method) return [] as string[];
    const cleanedMethods = parsed.rows
      .map((row) => normalizeCellValue(row.raw[mapping.method!] ?? ''))
      .filter((value) => value !== '' && !/^\d+$/.test(value));
    return Array.from(new Set(cleanedMethods)).sort();
  }, [parsed, mapping.method]);

  const availableProducts = useMemo(() => {
    if (!parsed || !mapping.product) return [] as string[];
    return Array.from(
      new Set(parsed.rows.map((row) => String(row.raw[mapping.product!] ?? '').trim()).filter(Boolean))
    ).sort();
  }, [parsed, mapping.product]);

  const availableMonths = useMemo(() => getCurrentPreviousMonths(), []);

  useEffect(() => {
    const reportingMonths = getCurrentPreviousMonths();
    const currentMonth = reportingMonths[reportingMonths.length - 1] ?? null;
    const selectedMonth = filters.monthRange[1] ?? filters.monthRange[0];
    const nextMonth = selectedMonth && reportingMonths.includes(selectedMonth) ? selectedMonth : currentMonth;

    if (!nextMonth) return;

    if (filters.monthRange[0] !== nextMonth || filters.monthRange[1] !== nextMonth) {
      setFilters((prev) => ({
        ...prev,
        monthRange: [nextMonth, nextMonth]
      }));
    }
  }, [filters.monthRange]);

  useEffect(() => {
    if (hasSavedFilters !== false) return;
    if (autoAppliedFilters.current) return;
    if (!parsed) return;
    if (!availableMethods.length && !availableProducts.length) return;

    setFilters((prev) => {
      const defaults = buildDefaultFilters(availableMethods, availableProducts, availableMonths);
      return {
        ...defaults,
        monthRange: prev.monthRange[0] || prev.monthRange[1] ? prev.monthRange : defaults.monthRange
      };
    });
    autoAppliedFilters.current = true;
  }, [availableMethods, availableProducts, availableMonths, hasSavedFilters, parsed]);

  const canRun = Boolean(parsed?.rows?.length && requiredMapped);

  const currentSignature = useMemo(() => {
    return makeSignature({ selectedSheet, headerRowIndex, mapping, rules, filters });
  }, [selectedSheet, headerRowIndex, mapping, rules, filters]);

  const resultsDirty = Boolean(calculation && lastRunSignature && lastRunSignature !== currentSignature);
  const selectedSheetFilterInfo =
    selectedSheet && workbookInfo ? workbookInfo.sheetFilters[selectedSheet] : null;
  const reportingMonths = useMemo(() => getCurrentPreviousMonths(), []);
  const selectedReportingMonth = filters.monthRange[1] ?? filters.monthRange[0] ?? reportingMonths[reportingMonths.length - 1] ?? null;
  const selectedMonthKind =
    selectedReportingMonth && reportingMonths.length
      ? selectedReportingMonth === reportingMonths[reportingMonths.length - 1]
        ? 'Current month'
        : 'Previous month'
      : null;

  const handleFile = async (file?: File) => {
    if (!file) return;
    setWebError(null);
    const wb = await readWorkbook(file);
    setWorkbook(wb);
    setWorkbookInfo({
      name: file.name,
      size: file.size,
      sheetNames: wb.SheetNames,
      sheetFilters: getWorkbookFilterInfo(wb),
      sourceType: 'excel'
    });
    const feed = wb.SheetNames.find((name) => name.toLowerCase() === 'feed');
    setSelectedSheet(feed ?? wb.SheetNames[0] ?? null);
    setCalculation(null);
    setLastRunSignature(null);
    setShowAdvanced(false);
    setLastRefreshedAt(new Date().toLocaleString());
    setShowExcelFallback(false);
    autoAppliedFilters.current = false;
  };

  const handleLoadWeb = useCallback(async () => {
    setIsLoadingWeb(true);
    setWebLoadStatus('loading');
    setWebError(null);
    setShowExcelFallback(false);
    try {
      const { workbook: wb, feedUrl, rowCount } = await readWebFeed(webUrl);
      setWorkbook(wb);
      setWorkbookInfo({
        name: 'FBC PRF web feed',
        size: 0,
        sheetNames: wb.SheetNames,
        sheetFilters: getWorkbookFilterInfo(wb),
        sourceType: 'web',
        sourceUrl: feedUrl,
        rowCount
      });
      setWebUrl(feedUrl);
      setSelectedSheet(wb.SheetNames[0] ?? null);
      setCalculation(null);
      setLastRunSignature(null);
      setShowAdvanced(false);
      setLastRefreshedAt(new Date().toLocaleString());
      setWebLoadStatus('ready');
      autoAppliedFilters.current = false;
    } catch (error) {
      setWebError(error instanceof Error ? error.message : 'Could not load the web feed.');
      setWebLoadStatus('failed');
    } finally {
      setIsLoadingWeb(false);
    }
  }, [webUrl]);

  useEffect(() => {
    if (didAutoLoadWeb.current) return;
    didAutoLoadWeb.current = true;
    handleLoadWeb();
  }, [handleLoadWeb]);

  const handleClear = () => {
    setWorkbook(null);
    setWorkbookInfo(null);
    setSelectedSheet(null);
    setSheetRows([]);
    setHeaderRowIndex(0);
    setMapping(emptyMapping);
    setRules(DEFAULT_RULES);
    setFilters(buildDefaultFilters());
    setCalculation(null);
    setLastRunSignature(null);
    setShowAdvanced(false);
    setHasSavedFilters(false);
    setWebError(null);
    setWebLoadStatus('idle');
    setShowExcelFallback(false);
    setLastRefreshedAt(null);
    autoAppliedFilters.current = false;
    void handleLoadWeb();
  };

  const handleSavePreset = (name: string) => {
    addPreset(name, mapping, rules, filters);
    setPresets(loadPresets());
  };

  const handleLoadPreset = (id: string) => {
    const preset = getPreset(id);
    if (!preset) return;
    setMapping({ ...emptyMapping, ...preset.mapping });
    setRules(preset.rules);
    setFilters(preset.filters);
  };

  const handleDeletePreset = (id: string) => {
    deletePreset(id);
    setPresets(loadPresets());
  };

  const handleAutoMatch = () => {
    if (!parsed?.headers?.length) return;
    setMapping((prev) => ({ ...prev, ...suggestMapping(parsed.headers) }));
  };

  const handleCalculate = useCallback(() => {
    if (!parsed || !requiredMapped) return;
    const rawRows = parsed.rows.map((entry) => entry.raw);
    const result = calculateMetrics(rawRows, mapping, rules, filters);
    setCalculation(result);
    setLastRunSignature(currentSignature);
  }, [parsed, requiredMapped, mapping, rules, filters, currentSignature]);

  const readyToRun = Boolean(workbook && selectedSheet && parsed?.headers?.length && requiredMapped);

  useEffect(() => {
    if (!readyToRun) return;
    if (lastRunSignature === currentSignature) return;
    handleCalculate();
  }, [readyToRun, lastRunSignature, currentSignature, handleCalculate]);

  const scrollToRef = (ref: RefObject<HTMLDivElement>) => {
    if (!ref.current) return;
    ref.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border bg-card/40">
        <div className="mx-auto max-w-6xl px-6 py-10">
          <h1 className="text-center text-2xl font-semibold">SLA Turnaround Report</h1>
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl items-start gap-6 px-6 py-6 lg:grid-cols-[280px_1fr]">
        <aside className="min-w-0 space-y-4">
          <div className="rounded-lg border border-border bg-card p-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-sm font-semibold">Dataset</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {workbookInfo ? (workbookInfo.sourceType === 'web' ? 'Loaded web feed' : 'Loaded workbook') : 'No data selected'}
                </p>
              </div>
              <Button type="button" variant="outline" size="sm" onClick={handleClear}>
                Reset
              </Button>
            </div>
            {workbookInfo ? (
              <div className="mt-3 space-y-1 text-xs">
                <p className="font-semibold">{workbookInfo.name}</p>
                {workbookInfo.sourceType === 'web' ? (
                  <p className="text-muted-foreground">{workbookInfo.rowCount ?? 0} rows loaded from web feed</p>
                ) : null}
                {workbookInfo.sourceUrl ? <p className="truncate text-muted-foreground">{workbookInfo.sourceUrl}</p> : null}
                <p className="text-muted-foreground">
                  {workbookInfo.sourceType === 'web'
                    ? `${workbookInfo.sheetNames.length} sheets`
                    : `${(workbookInfo.size / 1024).toFixed(1)} KB · ${workbookInfo.sheetNames.length} sheets`}
                </p>
                {selectedSheet ? (
                  <p className="text-muted-foreground">Current sheet: <span className="font-semibold text-foreground">{selectedSheet}</span></p>
                ) : null}
                {selectedSheetFilterInfo?.hasAutoFilter ? (
                  <p className="text-amber-700">
                    Excel filter is on{selectedSheetFilterInfo.range ? ` (${selectedSheetFilterInfo.range})` : ''}.
                  </p>
                ) : null}
              </div>
            ) : null}
          </div>
        </aside>

        <section className="min-w-0">
          <Card>
            <CardHeader>
              <CardTitle>Required vs shipped report</CardTitle>
              <p className="text-sm text-muted-foreground">
                Web data loads automatically. Excel upload is available only if web data cannot be loaded.
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              {!workbookInfo && webLoadStatus !== 'failed' ? (
                <Alert>
                  <AlertTitle>Loading web data...</AlertTitle>
                  <AlertDescription>Fetching the latest sample request feed.</AlertDescription>
                </Alert>
              ) : null}

              {!workbookInfo && webLoadStatus === 'failed' ? (
                <Alert className="border-destructive/30 bg-destructive/10">
                  <AlertTitle>Web data could not be loaded</AlertTitle>
                  <AlertDescription className="space-y-3">
                    <p>{webError ?? 'You can retry or upload Excel instead.'}</p>
                    <div className="flex flex-wrap gap-2">
                      <Button type="button" variant="secondary" onClick={handleLoadWeb} disabled={isLoadingWeb}>
                        {isLoadingWeb ? 'Loading web data...' : 'Retry web data'}
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setShowExcelFallback(true)}>
                        Upload Excel instead
                      </Button>
                    </div>
                  </AlertDescription>
                </Alert>
              ) : null}

              {!workbookInfo && webLoadStatus === 'failed' && showExcelFallback ? (
                <StepUpload workbookInfo={workbookInfo} onFile={handleFile} onClear={handleClear} />
              ) : null}

              {resultsDirty ? (
                <Alert>
                  <AlertTitle>Settings changed</AlertTitle>
                  <AlertDescription>
                    Rules or filters changed since the last run. Results will auto-refresh once ready.
                  </AlertDescription>
                </Alert>
              ) : null}

              {selectedSheetFilterInfo?.hasAutoFilter ? (
                <Alert className="border-amber-400 bg-amber-50 text-amber-950">
                  <AlertTitle>Excel filter detected on this sheet</AlertTitle>
                  <AlertDescription className="text-amber-900">
                    The selected sheet has an active autofilter
                    {selectedSheetFilterInfo.range ? ` on ${selectedSheetFilterInfo.range}` : ''}. The app reads all
                    rows in the worksheet, including rows hidden by Excel filters. Clear filters in Excel before upload
                    if the report should only use visible rows.
                  </AlertDescription>
                </Alert>
              ) : null}

              {parsed ? (
                <FiltersPanel
                  filters={filters}
                  onChangeFilters={(next) => {
                    setFilters(next);
                    setCalculation(null);
                    setLastRunSignature(null);
                  }}
                  availableMethods={availableMethods}
                  availableProducts={availableProducts}
                  availableMonths={availableMonths}
                />
              ) : null}

              {workbookInfo ? (
                <StepResults
                  calculation={calculation}
                  filters={filters}
                  selectedMonth={selectedReportingMonth}
                  selectedMonthKind={selectedMonthKind}
                  dataSourceLabel={workbookInfo.sourceType === 'web' ? 'Web data' : 'Excel fallback'}
                  rowsLoaded={workbookInfo.rowCount ?? parsed?.rows.length ?? 0}
                  lastRefreshedAt={lastRefreshedAt}
                  excelFileName={workbookInfo.sourceType === 'excel' ? workbookInfo.name : null}
                  onRetryWeb={workbookInfo.sourceType === 'web' ? handleLoadWeb : undefined}
                  isRetryingWeb={isLoadingWeb}
                />
              ) : null}
            </CardContent>
          </Card>

          {workbookInfo ? (
          <Card className="mt-6">
            <CardHeader className="flex flex-row items-center justify-between gap-3">
              <div>
                <CardTitle>Settings &amp; Advanced</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Adjust shipped status matching rules and manage presets. Hidden by default.
                </p>
              </div>
              <Button type="button" variant="outline" size="sm" onClick={() => setShowAdvanced((prev) => !prev)}>
                {showAdvanced ? 'Collapse' : 'Expand'}
              </Button>
            </CardHeader>
            {showAdvanced ? (
              <CardContent className="space-y-6">
                {workbookInfo ? (
                  <div ref={importRef} className="space-y-4">
                    <div>
                      <p className="text-sm font-semibold">Import settings</p>
                      <p className="text-xs text-muted-foreground">
                        Auto-detection is used by default. Expand this only if the wrong sheet, header row, or column mapping was detected.
                      </p>
                    </div>
                    <StepSheet
                      sheetNames={workbookInfo.sheetNames}
                      selectedSheet={selectedSheet}
                      sheetFilters={workbookInfo.sheetFilters}
                      onSelectSheet={(sheet) => {
                        setSelectedSheet(sheet);
                        setCalculation(null);
                        setLastRunSignature(null);
                        autoAppliedFilters.current = false;
                      }}
                    />
                    {sheetRows.length ? (
                      <StepHeader
                        headerRowIndex={headerRowIndex}
                        rows={sheetRows}
                        onChangeHeaderRowIndex={(index) => {
                          setHeaderRowIndex(index);
                          setCalculation(null);
                          setLastRunSignature(null);
                          autoAppliedFilters.current = false;
                        }}
                      />
                    ) : null}
                    {parsed ? (
                      <StepMapping
                        headers={parsed.headers}
                        rows={parsed.rows}
                        mapping={mapping}
                        onChange={(next) => {
                          setMapping(next);
                          setCalculation(null);
                          setLastRunSignature(null);
                        }}
                        requiredFields={REQUIRED_FIELDS}
                        optionalFields={OPTIONAL_FIELDS}
                        onAutoMatch={handleAutoMatch}
                        onJumpToHeader={() => scrollToRef(importRef)}
                      />
                    ) : null}
                  </div>
                ) : null}

                {workbookInfo ? <Separator /> : null}

                <div ref={rulesRef} className="space-y-4">
                  <div>
                    <p className="text-sm font-semibold">Rules</p>
                    <p className="text-xs text-muted-foreground">
                      Adjust shipped status matching. Filters are available directly above the results.
                    </p>
                  </div>
                  <StepRules
                    rules={rules}
                    onChangeRules={(next) => {
                      setRules(next);
                      setCalculation(null);
                      setLastRunSignature(null);
                    }}
                  />
                </div>

                <Separator />

                <div ref={reviewRef} className="space-y-4">
                  <div>
                    <p className="text-sm font-semibold">Review &amp; presets</p>
                    <p className="text-xs text-muted-foreground">
                      Save reusable presets or validate the run summary before sharing results.
                    </p>
                  </div>
                  <StepReview
                    workbookName={workbookInfo?.name ?? null}
                    totalRows={parsed?.rows?.length ?? 0}
                    rules={rules}
                    filters={filters}
                    presets={presets}
                    canRun={canRun}
                    onSavePreset={handleSavePreset}
                    onLoadPreset={handleLoadPreset}
                    onDeletePreset={handleDeletePreset}
                    onJumpToRules={() => {
                      setShowAdvanced(true);
                      scrollToRef(rulesRef);
                    }}
                  />
                </div>
              </CardContent>
            ) : null}
          </Card>
          ) : null}
        </section>
      </main>
    </div>
  );
}
