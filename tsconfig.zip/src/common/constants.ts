import type { FieldKey, FiltersConfig, RequiredFieldKey } from '@/types';

export const REQUIRED_FIELDS: Array<{ key: RequiredFieldKey; label: string }> = [
  { key: 'order_date', label: 'Order date' },
  { key: 'shipping_date', label: 'Shipped date' },
  { key: 'required_arrival_date', label: 'Required date' },
  { key: 'status', label: 'Status' },
  { key: 'method', label: 'Shipping method' },
  { key: 'product', label: 'Product' },
  { key: 'destination_country', label: 'Destination country' }
];

export const OPTIONAL_FIELDS: Array<{ key: FieldKey; label: string }> = [
  { key: 'order_id', label: 'Order number' },
  { key: 'customer', label: 'Customer' }
];

export const DEFAULT_RULES = {
  excludeChina: true,
  statusMatchers: ['shipped', 'shipped out', 'delivered', 'sampling finished'],
  statusRegex: ''
};

export const DEFAULT_PRODUCT_FILTERS = ['Duvet', 'Bed set', 'Pillow pair', 'Pillow'];

export const DEFAULT_FILTERS: FiltersConfig = {
  methods: [],
  products: DEFAULT_PRODUCT_FILTERS,
  monthRange: [null, null],
  deliveryNotRequired: true
};

function normalizeFilterValue(value: string) {
  return value.trim().toLowerCase().replace(/\s+/g, ' ');
}

export function matchesDefaultProduct(product: string) {
  const normalized = normalizeFilterValue(product);
  return DEFAULT_PRODUCT_FILTERS.some((defaultProduct) => normalizeFilterValue(defaultProduct) === normalized);
}

export function matchesDefaultMethod(method: string) {
  const normalized = normalizeFilterValue(method);
  const isEstoniaToUk = normalized.includes('estonia to uk') || (normalized.includes('estonia') && normalized.includes('uk'));
  const isCustomerMethod = normalized.includes('customer');
  return isEstoniaToUk || isCustomerMethod;
}

export function getDefaultProductFilters(availableProducts: string[] = []) {
  const matched = availableProducts.filter(matchesDefaultProduct);
  return matched.length ? matched : [...DEFAULT_PRODUCT_FILTERS];
}

export function getDefaultMethodFilters(availableMethods: string[] = []) {
  return availableMethods.filter(matchesDefaultMethod);
}

export function formatCalendarMonthKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
}

export function addCalendarMonths(date: Date, amount: number) {
  return new Date(date.getFullYear(), date.getMonth() + amount, 1);
}

/**
 * Manager reports are limited to the user's actual current calendar month and
 * the previous calendar month. Do not derive these months from feed data,
 * because future required dates can appear in the feed.
 */
export function getCurrentPreviousMonths(today = new Date()) {
  const current = new Date(today.getFullYear(), today.getMonth(), 1);
  const previous = addCalendarMonths(current, -1);
  return [formatCalendarMonthKey(previous), formatCalendarMonthKey(current)];
}

export function buildDefaultFilters(
  availableMethods: string[] = [],
  availableProducts: string[] = [],
  availableMonths: string[] = []
): FiltersConfig {
  void availableMonths;
  const reportingMonths = getCurrentPreviousMonths();
  const latestMonth = reportingMonths[reportingMonths.length - 1] ?? null;
  return {
    ...DEFAULT_FILTERS,
    methods: getDefaultMethodFilters(availableMethods),
    products: getDefaultProductFilters(availableProducts),
    monthRange: latestMonth ? [latestMonth, latestMonth] : [null, null]
  };
}
