import * as XLSX from 'xlsx';
import type { SheetFilterInfo } from '@/types';

export async function readWorkbook(file: File) {
  const buffer = await file.arrayBuffer();
  return XLSX.read(buffer, { type: 'array', cellDates: true });
}

export function getSheetRows(workbook: XLSX.WorkBook, sheetName: string) {
  const sheet = workbook.Sheets[sheetName];
  if (!sheet) return [] as unknown[][];
  return XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true, defval: '' }) as unknown[][];
}

export function getSheetFilterInfo(workbook: XLSX.WorkBook, sheetName: string): SheetFilterInfo {
  const sheet = workbook.Sheets[sheetName] as (XLSX.WorkSheet & {
    '!autofilter'?: string | { ref?: string };
  }) | undefined;

  const autoFilter = sheet?.['!autofilter'];
  if (!autoFilter) return { hasAutoFilter: false };

  return {
    hasAutoFilter: true,
    range: typeof autoFilter === 'string' ? autoFilter : autoFilter.ref
  };
}

export function getWorkbookFilterInfo(workbook: XLSX.WorkBook) {
  return Object.fromEntries(
    workbook.SheetNames.map((sheetName) => [sheetName, getSheetFilterInfo(workbook, sheetName)])
  );
}

export function getSheetSample(workbook: XLSX.WorkBook, sheetName: string, rows = 5) {
  const sheetRows = getSheetRows(workbook, sheetName);
  return sheetRows.slice(0, rows);
}
