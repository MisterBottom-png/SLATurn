import * as XLSX from 'xlsx';

export const DEFAULT_WEB_FEED_URL = 'http://fbc-prf.online/sample-request/web/submissions/feed';

const FEED_FIELDS = [
  'accuracy_to_spec',
  'additional_comments',
  'binding_colour',
  'care_label',
  'care_label_code',
  'carrier_cost_usd',
  'china',
  'comments',
  'compressed',
  'country',
  'courier_cost_usd',
  'cover_fabric_tick_shell',
  'current_status',
  'customer',
  'edge_finishing',
  'factory',
  'filling_fibres_and_',
  'fx_rate',
  'needle_spacing',
  'number_of_units',
  'order_date',
  'order_number',
  'order_raised_by',
  'packaging',
  'prf_number',
  'product',
  'product_code',
  'product_ref',
  'required_date_of_arrival',
  'sample_type',
  'shipping_date',
  'shipping_method',
  'ship_to',
  'size_autocomplete',
  'stitch_pattern',
  'tog_weight',
  'total_cost_of_order',
  'tracking'
];

interface WebFeedResponse {
  items?: unknown[];
}

function normalizeWebFeedUrl(url: string) {
  const trimmed = url.trim();
  const initialUrl = !trimmed ? DEFAULT_WEB_FEED_URL : trimmed;
  const safeUrl =
    typeof window !== 'undefined' && window.location.protocol === 'https:' && initialUrl.startsWith('http://')
      ? initialUrl.replace(/^http:\/\//, 'https://')
      : initialUrl;

  if (safeUrl.includes('/sample-request/web/submissions/feed')) return safeUrl;
  if (safeUrl.includes('/sample-request/web/submissions')) {
    let parsed: URL;
    try {
      parsed = new URL(safeUrl);
    } catch {
      throw new Error('Enter a valid submissions URL or feed URL.');
    }
    return `${parsed.origin}/sample-request/web/submissions/feed`;
  }
  return trimmed;
}

function asRecord(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  const record = value as Record<string, unknown>;
  const columnRecord = record.Column1;
  if (columnRecord && typeof columnRecord === 'object' && !Array.isArray(columnRecord)) {
    return columnRecord as Record<string, unknown>;
  }
  return record;
}

function formatFeedValue(value: unknown): string {
  if (value === null || value === undefined) return '';
  if (Array.isArray(value)) return value.map(formatFeedValue).filter(Boolean).join(', ');
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
}

function orderNumberSort(left: Record<string, unknown>, right: Record<string, unknown>) {
  return formatFeedValue(right.order_number).localeCompare(formatFeedValue(left.order_number), undefined, {
    numeric: true,
    sensitivity: 'base'
  });
}

function shouldUseLocalProxy() {
  const hostname = typeof window !== 'undefined' ? window.location.hostname : '';
  return hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1';
}

function isOpenedFromFile() {
  return typeof window !== 'undefined' && window.location.protocol === 'file:';
}

export async function readWebFeed(url: string) {
  let feedUrl: string;
  try {
    feedUrl = normalizeWebFeedUrl(url);
  } catch (error) {
    throw error instanceof Error ? error : new Error('Enter a valid web feed URL.');
  }

  if (isOpenedFromFile()) {
    throw new Error(
      'Single-file mode cannot load the web feed because the feed server blocks browser access from local files. Upload Excel instead, or ask the feed owner to enable CORS for this report.'
    );
  }

  let response: Response;

  try {
    response = await fetch(shouldUseLocalProxy() ? '/api/web-feed' : feedUrl, {
      headers: { Accept: 'application/json' }
    });
  } catch (error) {
    throw new Error(
      error instanceof TypeError
        ? 'Could not reach the web feed. The site may be blocking browser access with CORS, or the network is unavailable.'
        : 'Could not reach the web feed.'
    );
  }

  if (!response.ok) {
    throw new Error(`Web feed returned ${response.status} ${response.statusText}.`);
  }

  const payload = (await response.json()) as WebFeedResponse;
  if (!Array.isArray(payload.items)) {
    throw new Error('Web feed did not contain an items array.');
  }

  const records = payload.items.map(asRecord).sort(orderNumberSort);
  const extraFields = Array.from(
    new Set(records.flatMap((record) => Object.keys(record)).filter((field) => !FEED_FIELDS.includes(field)))
  ).sort();
  const fields = [...FEED_FIELDS, ...extraFields];
  const headers = fields.map((field) => `Column1.${field}`);
  const rows = records.map((record) => fields.map((field) => formatFeedValue(record[field])));
  const worksheet = XLSX.utils.aoa_to_sheet([headers, ...rows]);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'web');

  return {
    workbook,
    feedUrl,
    rowCount: records.length
  };
}
