import { formatMonthKey, parseDateSafe } from '@/parsing/date';
import { normalizeCellValue } from '@/parsing/rows';
import type { CalculationResult, EnrichedRow, FieldMapping, FiltersConfig, MonthlySummary, RulesConfig } from '@/types';

// Required mapping columns for the calculation flow.
const REQUIRED_MAPPED_FIELDS: Array<keyof FieldMapping> = [
  'order_date',
  'shipping_date',
  'required_arrival_date',
  'status',
  'method',
  'product',
  'destination_country'
];

// Fields that must be present per row before it can be included in KPI totals.
const REQUIRED_VALUE_FIELDS: Array<keyof FieldMapping> = [
  'order_date',
  'shipping_date',
  'required_arrival_date',
  'status',
  'method',
  'product',
  'destination_country'
];

const DATE_FIELD_LABELS: Partial<Record<keyof FieldMapping, string>> = {
  order_date: 'Order date',
  shipping_date: 'Shipped date',
  required_arrival_date: 'Required date'
};

function getEnrichedValue(row: EnrichedRow, field: keyof FieldMapping) {
  switch (field) {
    case 'order_date':
      return row.orderDate;
    case 'shipping_date':
      return row.shippingDate;
    case 'required_arrival_date':
      return row.requiredArrivalDate;
    case 'status':
      return row.status;
    case 'method':
      return row.method;
    case 'product':
      return row.product;
    case 'destination_country':
      return row.destinationCountry;
    case 'order_id':
      return row.orderId;
    case 'customer':
      return row.customer;
    default:
      return null;
  }
}

function getMappedValue(row: Record<string, unknown>, mapping: FieldMapping, key: string) {
  const column = mapping[key];
  if (!column) return '';
  return row[column] ?? '';
}

function escapeRegex(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function matchStatus(status: string, rules: RulesConfig) {
  const listMatch = rules.statusMatchers.some((matcher) => {
    const normalizedMatcher = matcher.trim().toLowerCase();
    if (!normalizedMatcher) return false;
    if (status.trim().toLowerCase() === normalizedMatcher) return true;
    const regex = new RegExp(`\\b${escapeRegex(normalizedMatcher)}\\b`, 'i');
    return regex.test(status);
  });
  if (rules.statusRegex) {
    try {
      const regex = new RegExp(rules.statusRegex, 'i');
      return regex.test(status) || listMatch;
    } catch {
      return listMatch;
    }
  }
  return listMatch;
}

function daysBetween(start: Date, end: Date) {
  const diff = end.getTime() - start.getTime();
  return Math.round(diff / 86400000);
}

function cleanShippingMethod(method: string) {
  return method.trim().replace(/\s+/g, ' ');
}

function normalizeFilterValue(value: string) {
  return value.trim().toLowerCase().replace(/\s+/g, ' ');
}

function filterIncludesValue(filters: string[], value: string) {
  const normalizedValue = normalizeFilterValue(value);
  return filters.some((filterValue) => normalizeFilterValue(filterValue) === normalizedValue);
}

function isDeliveryNotRequired(method: string) {
  return normalizeFilterValue(cleanShippingMethod(method)) === 'delivery not required';
}

function rowPassesScopeFilters(row: EnrichedRow, filters: FiltersConfig) {
  const deliveryNotRequiredRow = isDeliveryNotRequired(row.method);
  if (!filters.deliveryNotRequired && deliveryNotRequiredRow) return false;

  if (
    filters.methods.length &&
    !filterIncludesValue(filters.methods, row.method) &&
    !(filters.deliveryNotRequired && deliveryNotRequiredRow)
  ) {
    return false;
  }

  if (filters.products.length && !filterIncludesValue(filters.products, row.product)) return false;

  return true;
}

function rowIsInSelectedMonth(monthKey: string | null, filters: FiltersConfig) {
  if (!monthKey) return false;
  if (filters.monthRange[0] && monthKey < filters.monthRange[0]) return false;
  if (filters.monthRange[1] && monthKey > filters.monthRange[1]) return false;
  return true;
}

function getCorrectionMonthKey(row: EnrichedRow) {
  return formatMonthKey(row.shippingDate ?? row.requiredArrivalDate ?? row.orderDate);
}

function getMissingRequiredFields(row: EnrichedRow) {
  return REQUIRED_VALUE_FIELDS.filter((field) => {
    const value = getEnrichedValue(row, field);
    return !value;
  });
}

function getMissingDateFields(row: EnrichedRow) {
  return (['order_date', 'shipping_date', 'required_arrival_date'] as Array<keyof FieldMapping>)
    .filter((field) => !getEnrichedValue(row, field))
    .map((field) => DATE_FIELD_LABELS[field] ?? String(field));
}

function formatMissingDateReason(missingDateFields: string[]) {
  return `Missing or invalid date: ${missingDateFields.join(', ')}`;
}

function getOrderNumbers(rows: EnrichedRow[]) {
  return rows
    .map((row) => row.orderId?.trim())
    .filter((value): value is string => Boolean(value));
}

export function calculateMetrics(
  rawRows: Record<string, unknown>[],
  mapping: FieldMapping,
  rules: RulesConfig,
  filters: FiltersConfig
): CalculationResult {
  const exclusions = new Map<string, number>();
  const excludedRows: Array<{ row: EnrichedRow; reason: string }> = [];

  const trackExclusion = (reason: string) => {
    exclusions.set(reason, (exclusions.get(reason) ?? 0) + 1);
  };

  const enriched: EnrichedRow[] = rawRows.map((row) => {
    const orderDate = parseDateSafe(getMappedValue(row, mapping, 'order_date'));
    const shippingDate = parseDateSafe(getMappedValue(row, mapping, 'shipping_date'));
    const requiredArrivalDate = parseDateSafe(getMappedValue(row, mapping, 'required_arrival_date'));

    const status = normalizeCellValue(getMappedValue(row, mapping, 'status'));
    const method = normalizeCellValue(getMappedValue(row, mapping, 'method'));
    const product = normalizeCellValue(getMappedValue(row, mapping, 'product'));
    const destinationCountry = normalizeCellValue(getMappedValue(row, mapping, 'destination_country'));
    const orderId = normalizeCellValue(getMappedValue(row, mapping, 'order_id'));
    const customer = normalizeCellValue(getMappedValue(row, mapping, 'customer'));

    const turnoverDays = orderDate && shippingDate ? Math.max(daysBetween(orderDate, shippingDate), 0) : null;
    const shipVsRequiredDays = shippingDate && requiredArrivalDate ? daysBetween(requiredArrivalDate, shippingDate) : null;

    const isOnTime = shippingDate && requiredArrivalDate ? shippingDate <= requiredArrivalDate : null;
    const axisDate = shippingDate;

    const baseRow: EnrichedRow = {
      orderDate,
      shippingDate,
      requiredArrivalDate,
      status,
      method,
      product,
      destinationCountry,
      orderId: orderId || undefined,
      customer: customer || undefined,
      turnoverDays,
      shipVsRequiredDays,
      missingDateFields: [],
      isOnTime,
      monthKey: formatMonthKey(axisDate),
      correctionMonthKey: null
    };

    return {
      ...baseRow,
      missingDateFields: getMissingDateFields(baseRow),
      correctionMonthKey: getCorrectionMonthKey(baseRow)
    };
  });

  const validRows = enriched.filter((row) => {
    const missingMapped = REQUIRED_MAPPED_FIELDS.some((field) => !mapping[field]);
    if (missingMapped) return false;
    return getMissingRequiredFields(row).length === 0;
  });

  const includedRows = enriched.filter((row) => {
    const missingMapped = REQUIRED_MAPPED_FIELDS.some((field) => !mapping[field]);
    if (missingMapped) {
      trackExclusion('Missing required fields');
      excludedRows.push({ row, reason: 'Missing required fields' });
      return false;
    }

    if (row.missingDateFields.length) {
      const reason = formatMissingDateReason(row.missingDateFields);
      if (rowPassesScopeFilters(row, filters) && rowIsInSelectedMonth(row.correctionMonthKey, filters)) {
        trackExclusion(reason);
        excludedRows.push({ row, reason });
      }
      return false;
    }

    const missingRequiredValues = getMissingRequiredFields(row).filter((field) => !DATE_FIELD_LABELS[field]);
    if (missingRequiredValues.length) {
      trackExclusion('Missing required fields');
      excludedRows.push({ row, reason: 'Missing required fields' });
      return false;
    }

    if (!matchStatus(row.status, rules)) {
      trackExclusion('Status mismatch');
      excludedRows.push({ row, reason: 'Status mismatch' });
      return false;
    }

    if (rules.excludeChina && row.destinationCountry.toLowerCase().includes('china')) {
      trackExclusion('Excluded country');
      excludedRows.push({ row, reason: 'Excluded country' });
      return false;
    }

    const deliveryNotRequiredRow = isDeliveryNotRequired(row.method);
    if (!filters.deliveryNotRequired && deliveryNotRequiredRow) {
      trackExclusion('Excluded delivery not required');
      excludedRows.push({ row, reason: 'Excluded delivery not required' });
      return false;
    }

    if (
      filters.methods.length &&
      !filterIncludesValue(filters.methods, row.method) &&
      !(filters.deliveryNotRequired && deliveryNotRequiredRow)
    ) {
      trackExclusion('Filtered out by method');
      excludedRows.push({ row, reason: 'Filtered out by method' });
      return false;
    }

    if (filters.products.length && !filterIncludesValue(filters.products, row.product)) {
      trackExclusion('Filtered out by product');
      excludedRows.push({ row, reason: 'Filtered out by product' });
      return false;
    }

    if (!rowIsInSelectedMonth(row.monthKey, filters)) {
      trackExclusion(row.monthKey ? 'Filtered out by month' : 'Missing month basis');
      excludedRows.push({ row, reason: row.monthKey ? 'Filtered out by month' : 'Missing month basis' });
      return false;
    }

    return true;
  });

  const monthly = buildMonthlySummary(includedRows);

  return {
    monthly,
    rows: includedRows,
    quality: {
      rawRows: rawRows.length,
      validRows: validRows.length,
      includedRows: includedRows.length,
      exclusions: Array.from(exclusions.entries()).map(([reason, count]) => ({ reason, count }))
    },
    excludedRows
  };
}

function buildMonthlySummary(rows: EnrichedRow[]): MonthlySummary[] {
  const grouped = new Map<string, EnrichedRow[]>();

  rows.forEach((row) => {
    if (!row.monthKey) return;
    if (!grouped.has(row.monthKey)) grouped.set(row.monthKey, []);
    grouped.get(row.monthKey)?.push(row);
  });

  return Array.from(grouped.entries())
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([month, monthRows]) => {
      const shipped = monthRows.length;
      const onTime = monthRows.filter((row) => row.isOnTime).length;
      const late = monthRows.filter((row) => row.isOnTime === false).length;
      const turnoverValues = monthRows
        .map((row) => row.turnoverDays)
        .filter((value): value is number => typeof value === 'number');
      const averageTurnover = turnoverValues.length
        ? turnoverValues.reduce((acc, value) => acc + value, 0) / turnoverValues.length
        : null;

      const differenceValues = monthRows
        .map((row) => row.shipVsRequiredDays)
        .filter((value): value is number => typeof value === 'number');
      const averageShipVsRequiredDays = differenceValues.length
        ? differenceValues.reduce((acc, value) => acc + value, 0) / differenceValues.length
        : null;
      const lateValues = differenceValues.filter((value) => value > 0);

      return {
        month,
        shipped,
        onTime,
        late,
        onTimeRate: shipped ? onTime / shipped : 0,
        averageTurnover: averageTurnover !== null ? Number(averageTurnover.toFixed(1)) : null,
        averageShipVsRequiredDays:
          averageShipVsRequiredDays !== null ? Number(averageShipVsRequiredDays.toFixed(1)) : null,
        orderNumbers: getOrderNumbers(monthRows),
        maxLateDays: lateValues.length ? Math.max(...lateValues) : 0,
        lateOrderNumbers: getOrderNumbers(monthRows.filter((row) => (row.shipVsRequiredDays ?? 0) > 0))
      };
    });
}
