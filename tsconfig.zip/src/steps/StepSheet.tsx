import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { SheetFilterInfo } from '@/types';

interface StepSheetProps {
  sheetNames: string[];
  selectedSheet: string | null;
  sheetFilters?: Record<string, SheetFilterInfo>;
  onSelectSheet: (sheet: string) => void;
}

export default function StepSheet({ sheetNames, selectedSheet, sheetFilters = {}, onSelectSheet }: StepSheetProps) {
  return (
    <div className="space-y-3">
      <Select value={selectedSheet ?? ''} onValueChange={onSelectSheet}>
        <SelectTrigger aria-label="Select sheet">
          <SelectValue className="truncate" placeholder="Select a sheet" />
        </SelectTrigger>
        <SelectContent>
          {sheetNames.map((sheet) => (
            <SelectItem key={sheet} value={sheet}>
              {sheetFilters[sheet]?.hasAutoFilter ? `${sheet} (filter on)` : sheet}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <p className="text-xs text-muted-foreground">
        Default sheet is <span className="font-semibold text-foreground">feed</span> (when present).
      </p>
    </div>
  );
}
