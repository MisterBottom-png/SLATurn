import { useMemo, useRef } from 'react';
import * as XLSX from 'xlsx';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { exportResultsToPdf } from '@/exports/pdf';
import MonthlyTable from '@/results/MonthlyTable';
import RowTable from '@/results/RowTable';
import ExcludedRowTable from '@/results/ExcludedRowTable';
import type { CalculationResult, EnrichedRow, FiltersConfig } from '@/types';

interface StepResultsProps {
  calculation: CalculationResult | null;
  filters: FiltersConfig;
  selectedMonth: string | null;
  selectedMonthKind: 'Current month' | 'Previous month' | null;
  dataSourceLabel: string;
  rowsLoaded: number;
  lastRefreshedAt: string | null;
  excelFileName?: string | null;
  onRetryWeb?: () => void;
  isRetryingWeb?: boolean;
}

interface ReportKpis {
  included: number;
  onTime: number;
  late: number;
  onTimeRate: string;
  lateRate: string;
  averageDays: string;
  missingDateRows: number;
}

export default function StepResults({
  calculation,
  filters,
  selectedMonth,
  selectedMonthKind,
  dataSourceLabel,
  rowsLoaded,
  lastRefreshedAt,
  excelFileName,
  onRetryWeb,
  isRetryingWeb = false
}: StepResultsProps) {
  const resultsRef = useRef<HTMLDivElement | null>(null);

  const lateRows = useMemo(
    () => (calculation?.rows ?? []).filter((row) => (row.shipVsRequiredDays ?? 0) > 0),
    [calculation]
  );
  const onTimeRows = useMemo(
    () => (calculation?.rows ?? []).filter((row) => row.isOnTime === true),
    [calculation]
  );
  const dateIssueRows = useMemo(
    () => (calculation?.excludedRows ?? []).filter((item) => item.row.missingDateFields.length),
    [calculation]
  );

  const sortedLateRows = useMemo(
    () => [...lateRows].sort((left, right) => (right.shipVsRequiredDays ?? 0) - (left.shipVsRequiredDays ?? 0)),
    [lateRows]
  );
  const sortedOnTimeRows = useMemo(
    () => [...onTimeRows].sort((left, right) => (left.shipVsRequiredDays ?? 0) - (right.shipVsRequiredDays ?? 0)),
    [onTimeRows]
  );

  const kpis = useMemo<ReportKpis | null>(() => {
    if (!calculation) return null;
    const included = calculation.rows.length;
    const onTime = onTimeRows.length;
    const late = lateRows.length;
    const diffs = calculation.rows
      .map((row) => row.shipVsRequiredDays)
      .filter((value): value is number => typeof value === 'number');
    const average = diffs.length ? diffs.reduce((sum, value) => sum + value, 0) / diffs.length : null;

    return {
      included,
      onTime,
      late,
      onTimeRate: included ? `${Math.round((onTime / included) * 100)}%` : '0%',
      lateRate: included ? `${Math.round((late / included) * 100)}%` : '0%',
      averageDays: average === null ? '—' : formatAverageDifference(average),
      missingDateRows: dateIssueRows.length
    };
  }, [calculation, dateIssueRows.length, lateRows.length, onTimeRows.length]);

  if (!calculation) {
    return (
      <Alert>
        <AlertDescription>Loading report data...</AlertDescription>
      </Alert>
    );
  }

  const canExport = Boolean(calculation.rows.length || calculation.excludedRows.length);
  const monthLabel = selectedMonth ?? 'No month selected';
  const sourceDetail = excelFileName ? `${dataSourceLabel}: ${excelFileName}` : dataSourceLabel;

  const handleExport = () => {
    const workbook = XLSX.utils.book_new();
    const metadata = [
      { label: 'Selected month', value: monthLabel },
      { label: 'Month type', value: selectedMonthKind ?? '' },
      { label: 'Data source', value: sourceDetail },
      { label: 'Rows loaded', value: rowsLoaded },
      { label: 'Last refreshed', value: lastRefreshedAt ?? '' },
      { label: 'Orders included', value: kpis?.included ?? 0 },
      { label: 'On-time orders', value: kpis?.onTime ?? 0 },
      { label: 'Late orders', value: kpis?.late ?? 0 },
      { label: 'On-time percentage', value: kpis?.onTimeRate ?? '0%' },
      { label: 'Late percentage', value: kpis?.lateRate ?? '0%' },
      { label: 'Average days early/late', value: kpis?.averageDays ?? '—' },
      { label: 'Missing/invalid date rows', value: kpis?.missingDateRows ?? 0 }
    ];
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(metadata), 'report_summary');

    const monthly = calculation.monthly.map((row) => ({
      selectedMonth: monthLabel,
      dataSource: sourceDetail,
      month: row.month,
      ordersIncluded: row.shipped,
      onTimeOrders: row.onTime,
      lateOrders: row.late,
      onTimePercentage: `${Math.round(row.onTimeRate * 100)}%`,
      latePercentage: row.shipped ? `${Math.round((row.late / row.shipped) * 100)}%` : '0%',
      averageDaysEarlyLate: formatAverageDifference(row.averageShipVsRequiredDays),
      maxLateDays: formatDayDifference(row.maxLateDays),
      orderNumbers: formatOrderNumbers(row.orderNumbers),
      lateOrderNumbers: formatOrderNumbers(row.lateOrderNumbers)
    }));
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(monthly), 'monthly_summary');
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(sortedLateRows.map(exportIncludedRow)), 'late_orders');
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(sortedOnTimeRows.map(exportIncludedRow)), 'on_time_orders');
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(calculation.rows.map(exportIncludedRow)), 'included_orders');
    XLSX.utils.book_append_sheet(
      workbook,
      XLSX.utils.json_to_sheet(calculation.excludedRows.map(exportExcludedRow)),
      'rows_needing_correction'
    );
    XLSX.writeFile(workbook, `required_vs_shipped_${selectedMonth ?? 'report'}.xlsx`);
  };

  const handleExportPdf = async () => {
    if (!resultsRef.current) return;
    await exportResultsToPdf(resultsRef.current, {
      filenamePrefix: `required_vs_shipped_${selectedMonth ?? 'report'}`,
      orientation: 'l',
      renderDelayMs: 0
    });
  };

  return (
    <div className="space-y-6" ref={resultsRef}>
      <section className="rounded-lg border border-border bg-card p-4" data-pdf-avoid-break="true">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase text-muted-foreground">Required vs shipped</p>
            <h2 className="mt-1 text-2xl font-semibold">SLA Turnaround Report</h2>
            <div className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
              <p>
                <span className="font-semibold">Selected month:</span> {monthLabel}
                {selectedMonthKind ? <span className="text-muted-foreground"> ({selectedMonthKind})</span> : null}
              </p>
              <p>
                <span className="font-semibold">Data source:</span> {sourceDetail}
              </p>
              <p>
                <span className="font-semibold">Rows loaded:</span> {rowsLoaded}
              </p>
              <p>
                <span className="font-semibold">Last refreshed:</span> {lastRefreshedAt ?? '—'}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {onRetryWeb ? (
              <Button type="button" variant="outline" onClick={onRetryWeb} disabled={isRetryingWeb}>
                {isRetryingWeb ? 'Loading web data...' : 'Retry web data'}
              </Button>
            ) : null}
            <Button type="button" variant="secondary" onClick={handleExportPdf} disabled={!canExport}>
              Export PDF
            </Button>
            <Button type="button" variant="secondary" onClick={handleExport} disabled={!canExport}>
              Export Excel
            </Button>
          </div>
        </div>
      </section>

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6" data-pdf-avoid-break="true">
        <KpiCard label="Orders included" value={kpis?.included ?? 0} />
        <KpiCard label="On-time orders" value={kpis?.onTime ?? 0} helper={kpis?.onTimeRate} />
        <KpiCard label="Late orders" value={kpis?.late ?? 0} helper={kpis?.lateRate} danger={Boolean(kpis?.late)} />
        <KpiCard label="On-time %" value={kpis?.onTimeRate ?? '-'} />
        <KpiCard label="Avg days early/late" value={kpis?.averageDays ?? '-'} />
        <KpiCard label="Missing dates" value={kpis?.missingDateRows ?? 0} danger={Boolean(kpis?.missingDateRows)} />
      </section>

      <section className="rounded-lg border border-border bg-card p-4" data-pdf-avoid-break="true">
        <p className="text-sm font-semibold">Report scope</p>
        <div className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
          <p>
            <span className="font-semibold">Products:</span>{' '}
            {filters.products.length ? filters.products.join(', ') : 'All products'}
          </p>
          <p>
            <span className="font-semibold">Methods:</span>{' '}
            {filters.methods.length ? filters.methods.join(', ') : 'All methods'}
          </p>
          <p>
            <span className="font-semibold">Delivery not required:</span>{' '}
            {filters.deliveryNotRequired ? 'Included' : 'Excluded'}
          </p>
        </div>
      </section>

      <OrderSection
        title="Late orders to review"
        description="Sorted by largest delay first. These orders shipped after the required date."
        rows={sortedLateRows}
        emptyText="No late orders in the selected month."
        tone="late"
      />

      <OrderSection
        title="On-time orders"
        description="Orders that shipped on or before the required date. Negative values are early."
        rows={sortedOnTimeRows}
        emptyText="No on-time orders in the selected month."
        tone="ontime"
      />

      <CorrectionSection rows={dateIssueRows} />

      <details className="rounded-lg border border-border bg-card p-4">
        <summary className="cursor-pointer text-sm font-semibold">Advanced details</summary>
        <div className="mt-4 space-y-6">
          <MonthlyTable data={calculation.monthly} />
          <div>
            <p className="mb-2 text-sm font-semibold">Included orders</p>
            <RowTable data={calculation.rows} />
          </div>
          <div>
            <p className="mb-2 text-sm font-semibold">All excluded rows</p>
            {calculation.excludedRows.length ? (
              <ExcludedRowTable data={calculation.excludedRows} />
            ) : (
              <Alert>
                <AlertDescription>No excluded rows recorded.</AlertDescription>
              </Alert>
            )}
          </div>
        </div>
      </details>
    </div>
  );
}

function KpiCard({
  label,
  value,
  helper,
  danger = false
}: {
  label: string;
  value: string | number;
  helper?: string;
  danger?: boolean;
}) {
  return (
    <div className={`rounded-lg border p-4 ${danger ? 'border-destructive/30 bg-destructive/10' : 'border-border bg-card'}`}>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 text-2xl font-semibold">{value}</p>
      {helper ? <p className="mt-1 text-xs text-muted-foreground">{helper}</p> : null}
    </div>
  );
}

function OrderSection({
  title,
  description,
  rows,
  emptyText,
  tone
}: {
  title: string;
  description: string;
  rows: EnrichedRow[];
  emptyText: string;
  tone: 'late' | 'ontime';
}) {
  return (
    <section className="rounded-lg border border-border bg-card p-4" data-pdf-avoid-break="true">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <p className="text-sm font-semibold">{title}</p>
          <p className="mt-1 text-xs text-muted-foreground">{description}</p>
        </div>
        <span className="rounded-full border border-border bg-muted/40 px-2.5 py-0.5 text-xs font-medium">
          {rows.length} order{rows.length === 1 ? '' : 's'}
        </span>
      </div>
      {rows.length ? (
        <div className="mt-3 overflow-auto rounded-lg border border-border">
          <table className="min-w-[860px] w-full text-left text-xs">
            <thead className="bg-card text-muted-foreground">
              <tr>
                <th className="px-3 py-2">Order number</th>
                <th className="px-3 py-2">Days early/late</th>
                <th className="px-3 py-2">Required date</th>
                <th className="px-3 py-2">Shipped date</th>
                <th className="px-3 py-2">Product</th>
                <th className="px-3 py-2">Method</th>
                <th className="px-3 py-2">Customer</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => (
                <tr key={`${row.orderId ?? title}-${index}`} className="border-t border-border">
                  <td className="px-3 py-2 font-semibold">{row.orderId ?? '—'}</td>
                  <td className="px-3 py-2">
                    <span
                      className={`rounded-full px-2 py-0.5 font-semibold ${
                        tone === 'late' ? 'bg-destructive/15 text-destructive' : 'bg-primary/10 text-primary'
                      }`}
                    >
                      {formatDayDifference(row.shipVsRequiredDays)}
                    </span>
                  </td>
                  <td className="px-3 py-2">{formatDate(row.requiredArrivalDate)}</td>
                  <td className="px-3 py-2">{formatDate(row.shippingDate)}</td>
                  <td className="px-3 py-2">{row.product}</td>
                  <td className="px-3 py-2">{row.method}</td>
                  <td className="px-3 py-2">{row.customer ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="mt-3 text-sm text-muted-foreground">{emptyText}</p>
      )}
    </section>
  );
}

function CorrectionSection({ rows }: { rows: Array<{ row: EnrichedRow; reason: string }> }) {
  return (
    <section className="rounded-lg border border-destructive/30 bg-destructive/10 p-4" data-pdf-avoid-break="true">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <p className="text-sm font-semibold text-destructive">Rows needing correction</p>
          <p className="mt-1 text-xs text-destructive/80">
            These rows have missing or invalid required, shipped, or order dates and are excluded until corrected.
          </p>
        </div>
        <span className="rounded-full border border-destructive/30 bg-background px-2.5 py-0.5 text-xs font-medium text-destructive">
          {rows.length} row{rows.length === 1 ? '' : 's'}
        </span>
      </div>
      {rows.length ? (
        <div className="mt-3 overflow-auto rounded-lg border border-destructive/30 bg-background">
          <table className="min-w-[760px] w-full text-left text-xs">
            <thead className="bg-card text-muted-foreground">
              <tr>
                <th className="px-3 py-2">Order number</th>
                <th className="px-3 py-2">Missing/invalid fields</th>
                <th className="px-3 py-2">Order date</th>
                <th className="px-3 py-2">Required date</th>
                <th className="px-3 py-2">Shipped date</th>
                <th className="px-3 py-2">Product</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((item, index) => (
                <tr key={`${item.row.orderId ?? 'missing'}-${index}`} className="border-t border-border text-destructive">
                  <td className="px-3 py-2 font-semibold">{item.row.orderId ?? '-'}</td>
                  <td className="px-3 py-2">{item.row.missingDateFields.join(', ')}</td>
                  <td className="px-3 py-2">{formatDate(item.row.orderDate)}</td>
                  <td className="px-3 py-2">{formatDate(item.row.requiredArrivalDate)}</td>
                  <td className="px-3 py-2">{formatDate(item.row.shippingDate)}</td>
                  <td className="px-3 py-2">{item.row.product}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="mt-3 text-sm text-destructive/80">No missing or invalid date rows in the selected month.</p>
      )}
    </section>
  );
}

function exportIncludedRow(row: EnrichedRow) {
  return {
    orderNumber: row.orderId ?? '',
    requiredDate: formatDate(row.requiredArrivalDate),
    shippedDate: formatDate(row.shippingDate),
    orderDate: formatDate(row.orderDate),
    daysEarlyLate: row.shipVsRequiredDays ?? '',
    daysEarlyLateLabel: formatDayDifference(row.shipVsRequiredDays),
    onTime: row.isOnTime === null ? '' : row.isOnTime ? 'Yes' : 'No',
    status: row.status,
    method: row.method,
    product: row.product,
    destinationCountry: row.destinationCountry,
    customer: row.customer ?? '',
    turnaroundDays: row.turnoverDays ?? '',
    month: row.monthKey ?? ''
  };
}

function exportExcludedRow(item: { row: EnrichedRow; reason: string }) {
  return {
    reason: item.reason,
    orderNumber: item.row.orderId ?? '',
    missingOrInvalidFields: item.row.missingDateFields.join(', '),
    orderDate: formatDate(item.row.orderDate),
    requiredDate: formatDate(item.row.requiredArrivalDate),
    shippedDate: formatDate(item.row.shippingDate),
    daysEarlyLate: item.row.shipVsRequiredDays ?? '',
    daysEarlyLateLabel: formatDayDifference(item.row.shipVsRequiredDays),
    status: item.row.status,
    method: item.row.method,
    product: item.row.product,
    destinationCountry: item.row.destinationCountry,
    customer: item.row.customer ?? ''
  };
}

function formatDate(value: Date | null | undefined) {
  if (!value || !(value instanceof Date)) return '—';
  return value.toISOString().slice(0, 10);
}

function formatAverageDifference(value: number | null | undefined) {
  if (typeof value !== 'number') return '—';
  if (value > 0) return `+${value.toFixed(1)} days late`;
  if (value < 0) return `${value.toFixed(1)} days early`;
  return '0.0 days on time';
}

function formatDayDifference(value: number | null | undefined) {
  if (typeof value !== 'number') return '—';
  const abs = Math.abs(value);
  const unit = abs === 1 ? 'day' : 'days';
  if (value > 0) return `+${value} ${unit} late`;
  if (value < 0) return `${value} ${unit} early`;
  return '0 days on time';
}

function formatOrderNumbers(values: string[] | undefined) {
  if (!values?.length) return '';
  return values.join(', ');
}
